
import { ABGInputs, ABGInterpretation } from '../types';

export const interpretABG = (inputs: ABGInputs): ABGInterpretation => {
  const { pH, pCO2, HCO3, PaO2, FiO2, Na, Cl, K, Albumin, BUN, Glucose, Age } = inputs;

  // 1. Konsistensi Fisiologis (Henderson-Hasselbalch check)
  const hPlus = Math.pow(10, -pH) * 1e9;
  const calculatedHPlus = 24 * (pCO2 / HCO3);
  const physiologicalConsistency = Math.abs(hPlus - calculatedHPlus) < (0.1 * hPlus);

  // 2. Gangguan Primer
  let primaryDisorder = "Normal";
  let secondaryDisorders: string[] = [];
  
  if (pH < 7.35) {
    if (pCO2 > 45 && HCO3 >= 22) primaryDisorder = "Asidosis Respiratorik";
    else if (HCO3 < 22 && pCO2 <= 45) primaryDisorder = "Asidosis Metabolik";
    else primaryDisorder = "Asidosis Campuran (Metabolik & Respiratorik)";
  } else if (pH > 7.45) {
    if (pCO2 < 35 && HCO3 <= 26) primaryDisorder = "Alkalosis Respiratorik";
    else if (HCO3 > 26 && pCO2 >= 35) primaryDisorder = "Alkalosis Metabolik";
    else primaryDisorder = "Alkalosis Campuran (Metabolik & Respiratorik)";
  } else {
    if (pCO2 > 45 || pCO2 < 35 || HCO3 > 26 || HCO3 < 22) primaryDisorder = "Kompensasi Penuh atau Gangguan Campuran";
    else primaryDisorder = "Keseimbangan Asam-Basa Normal";
  }

  // 3. Aturan Kompensasi
  let compensationStatus = "Mengevaluasi kompensasi...";
  let expectedPCO2;
  let expectedHCO3;

  if (primaryDisorder.includes("Asidosis Metabolik")) {
    const wintersMin = (1.5 * HCO3) + 6; 
    const wintersMax = (1.5 * HCO3) + 10;
    expectedPCO2 = { min: wintersMin, max: wintersMax };
    if (pCO2 > wintersMax) secondaryDisorders.push("Asidosis Respiratorik Sekunder");
    else if (pCO2 < wintersMin) secondaryDisorders.push("Alkalosis Respiratorik Sekunder");
    else compensationStatus = "Kompensasi Respiratorik Sesuai (Rumus Winters)";
  } else if (primaryDisorder.includes("Alkalosis Metabolik")) {
    const expPCO2 = 0.7 * (HCO3 - 24) + 40;
    expectedPCO2 = { min: expPCO2 - 2, max: expPCO2 + 2 };
    if (pCO2 > expectedPCO2.max) secondaryDisorders.push("Asidosis Respiratorik Sekunder");
    else if (pCO2 < expectedPCO2.min) secondaryDisorders.push("Alkalosis Respiratorik Sekunder");
    else compensationStatus = "Kompensasi Respiratorik Sesuai";
  } else if (primaryDisorder.includes("Asidosis Respiratorik")) {
    const deltaP = pCO2 - 40;
    expectedHCO3 = { acute: 24 + (deltaP / 10), chronic: 24 + (3.5 * deltaP / 10) };
    const acuteDev = Math.abs(HCO3 - expectedHCO3.acute);
    const chronicDev = Math.abs(HCO3 - expectedHCO3.chronic);
    compensationStatus = acuteDev < chronicDev ? "Asidosis Respiratorik Akut" : "Asidosis Respiratorik Kronis";
  } else if (primaryDisorder.includes("Alkalosis Respiratorik")) {
    const deltaP = 40 - pCO2;
    expectedHCO3 = { acute: 24 - (2 * deltaP / 10), chronic: 24 - (5 * deltaP / 10) };
    const acuteDev = Math.abs(HCO3 - expectedHCO3.acute);
    const chronicDev = Math.abs(HCO3 - expectedHCO3.chronic);
    compensationStatus = acuteDev < chronicDev ? "Alkalosis Respiratorik Akut" : "Alkalosis Respiratorik Kronis";
  }

  // 4. Kalkulasi Anion Gap
  const observedAG = Na - (Cl + HCO3);
  const correctedAG = observedAG + (2.5 * (4.0 - Albumin));
  const isHighAG = correctedAG > 12;

  // 5. Delta Gap / Rasio Delta
  let deltaGap;
  if (isHighAG) {
    const deltaAG = correctedAG - 12;
    const deltaHCO3 = 24 - HCO3;
    const ratio = deltaHCO3 === 0 ? deltaAG : deltaAG / deltaHCO3;
    let interpretation = "";
    if (ratio < 0.4) interpretation = "Campuran HAGMA & NAGMA";
    else if (ratio < 1.0) interpretation = "Asidosis Metabolik AG Tinggi & NAGMA";
    else if (ratio <= 2.0) interpretation = "HAGMA Murni";
    else interpretation = "Campuran HAGMA & Alkalosis Metabolik";
    deltaGap = { ratio, interpretation };
  }

  // 6. Oksigenasi
  const pfRatio = PaO2 / (FiO2 / 100);
  let pfClass = "Normal";
  if (pfRatio < 100) pfClass = "ARDS Berat";
  else if (pfRatio < 200) pfClass = "ARDS Sedang";
  else if (pfRatio < 300) pfClass = "ARDS Ringan";

  const PAO2 = ((FiO2 / 100) * 713) - (pCO2 / 0.8);
  const aaGradient = Math.max(0, PAO2 - PaO2);
  const aaExpected = (Age / 4) + 4;
  const aaStatus = aaGradient > aaExpected ? "Gradien Meningkat (Shunt/VQ Mismatch)" : "Gradien Normal (Hipoventilasi/FiO2 Rendah)";

  return {
    physiologicalConsistency,
    hPlus,
    calculatedHPlus,
    primaryDisorder,
    secondaryDisorders,
    compensationStatus,
    expectedPCO2,
    expectedHCO3,
    anionGap: {
      observed: observedAG,
      corrected: correctedAG,
      isHigh: isHighAG
    },
    deltaGap,
    oxygenation: {
      pfRatio,
      pfClass,
      aaGradient,
      aaExpected,
      aaStatus
    }
  };
};
