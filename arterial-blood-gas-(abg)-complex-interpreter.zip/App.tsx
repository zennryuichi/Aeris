
import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  Droplets, 
  Wind, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ChevronRight,
  Gauge,
  Thermometer,
  Microscope,
  Stethoscope,
  Heart,
  Copy,
  Share2
} from 'lucide-react';
import { ABGInputs } from './types';
import { interpretABG } from './services/abgLogic';

const InputField = ({ label, name, value, onChange, min, max, step, unit, icon: Icon }: any) => (
  <div className="group flex flex-col gap-2 p-3 rounded-xl hover:bg-slate-800/30 transition-colors">
    <div className="flex justify-between items-center">
      <label htmlFor={name} className="text-[10px] font-bold uppercase tracking-[0.1em] text-slate-500 group-hover:text-cyan-400 transition-colors flex items-center gap-1.5">
        {Icon && <Icon className="w-3 h-3" />} {label}
      </label>
      <span className="text-[10px] mono text-slate-600 font-bold">{unit}</span>
    </div>
    <div className="relative">
      <input
        type="number"
        id={name}
        name={name}
        value={value}
        onChange={onChange}
        step={step}
        min={min}
        max={max}
        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500 transition-all mono"
      />
    </div>
  </div>
);

const App: React.FC = () => {
  const [inputs, setInputs] = useState<ABGInputs>({
    pH: 7.40,
    pCO2: 40,
    HCO3: 24,
    PaO2: 95,
    FiO2: 21,
    Na: 140,
    Cl: 104,
    K: 4.0,
    Albumin: 4.0,
    BUN: 15,
    Glucose: 100,
    Age: 40,
  });

  const [copied, setCopied] = useState(false);

  const diagnosis = useMemo(() => interpretABG(inputs), [inputs]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const handleCopyResults = () => {
    const text = `
BIO-SCAN PRO: LAPORAN ANALISIS GAS DARAH
----------------------------------------
HASIL LAB:
- pH: ${inputs.pH}
- pCO2: ${inputs.pCO2} mmHg
- HCO3: ${inputs.HCO3} mEq/L
- PaO2: ${inputs.PaO2} mmHg (FiO2: ${inputs.FiO2}%)
- Na/Cl: ${inputs.Na}/${inputs.Cl} mEq/L

DIAGNOSIS UTAMA:
${diagnosis.primaryDisorder}

INTERPRETASI:
- Kompensasi: ${diagnosis.compensationStatus}
- Anion Gap Terkoreksi: ${diagnosis.anionGap.corrected.toFixed(1)} (${diagnosis.anionGap.isHigh ? 'Tinggi' : 'Normal'})
${diagnosis.deltaGap ? `- Rasio Delta: ${diagnosis.deltaGap.ratio.toFixed(2)} (${diagnosis.deltaGap.interpretation})` : ''}
- Rasio P/F: ${diagnosis.oxygenation.pfRatio.toFixed(0)} (${diagnosis.oxygenation.pfClass})
- Gradien A-a: ${diagnosis.oxygenation.aaGradient.toFixed(1)}

Dihasilkan secara otomatis oleh BioScan Pro Core.
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const phProgress = Math.max(0, Math.min(100, ((inputs.pH - 6.8) / (7.8 - 6.8)) * 100));

  return (
    <div className="min-h-screen text-slate-200 p-4 md:p-6 max-w-[1600px] mx-auto">
      {/* Header Dinamis */}
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-8 bg-slate-900/50 p-6 rounded-3xl border border-slate-800 glass relative overflow-hidden">
        <div className="flex items-center gap-5 relative z-10">
          <div className="p-4 bg-cyan-500/10 rounded-2xl border border-cyan-500/20 group relative overflow-hidden">
             <div className="absolute inset-0 bg-cyan-400 opacity-0 group-hover:opacity-10 transition-opacity"></div>
             <Activity className="w-8 h-8 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight flex items-center gap-2">
              BIOSCAN <span className="text-cyan-400">PRO</span>
            </h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Inti Analitis BGA Lanjutan v3.0</p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-3 relative z-10">
           <button 
             onClick={handleCopyResults}
             className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-xs font-bold transition-all transform active:scale-95 ${copied ? 'bg-emerald-500 border-emerald-400 text-white' : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20 shadow-[0_0_15px_-5px_rgba(34,211,238,0.4)]'}`}
           >
             {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
             {copied ? 'Tersalin!' : 'Salin Laporan'}
           </button>
           <div className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-xs font-bold transition-all ${diagnosis.physiologicalConsistency ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
             {diagnosis.physiologicalConsistency ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
             Fisiologi: {diagnosis.physiologicalConsistency ? 'Konsisten' : 'Inkonsisten'}
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Kolom Kiri: Parameter */}
        <div className="lg:col-span-3 space-y-6">
          <div className="glass p-6 rounded-3xl border-slate-800">
            <h2 className="text-[10px] font-extrabold text-slate-500 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
              <Microscope className="w-4 h-4 text-cyan-500" /> Panel Data Laboratorium
            </h2>
            
            <div className="space-y-1">
              <h3 className="text-[9px] font-black text-slate-600 uppercase mb-2 px-3 tracking-widest">Dasar BGA</h3>
              <InputField label="pH" name="pH" value={inputs.pH} onChange={handleInputChange} min={6.8} max={7.8} step={0.01} unit="U" icon={Thermometer} />
              <InputField label="pCO2" name="pCO2" value={inputs.pCO2} onChange={handleInputChange} min={10} max={100} step={1} unit="mmHg" icon={Wind} />
              <InputField label="HCO3" name="HCO3" value={inputs.HCO3} onChange={handleInputChange} min={5} max={50} step={1} unit="mEq/L" icon={Droplets} />
              
              <h3 className="text-[9px] font-black text-slate-600 uppercase mt-4 mb-2 px-3 tracking-widest">Elektrolit & Celah</h3>
              <InputField label="Natrium (Na+)" name="Na" value={inputs.Na} onChange={handleInputChange} min={100} max={180} step={1} unit="mEq/L" />
              <InputField label="Klorida (Cl-)" name="Cl" value={inputs.Cl} onChange={handleInputChange} min={70} max={130} step={1} unit="mEq/L" />
              <InputField label="Albumin" name="Albumin" value={inputs.Albumin} onChange={handleInputChange} min={1} max={6} step={0.1} unit="g/dL" />
              
              <h3 className="text-[9px] font-black text-slate-600 uppercase mt-4 mb-2 px-3 tracking-widest">Oksigenasi</h3>
              <InputField label="PaO2" name="PaO2" value={inputs.PaO2} onChange={handleInputChange} min={20} max={500} step={1} unit="mmHg" icon={Activity} />
              <InputField label="FiO2" name="FiO2" value={inputs.FiO2} onChange={handleInputChange} min={21} max={100} step={1} unit="%" />
              <InputField label="Usia" name="Age" value={inputs.Age} onChange={handleInputChange} min={0} max={110} step={1} unit="Tahun" />
            </div>
          </div>
        </div>

        {/* Kolom Tengah/Kanan: Analisis */}
        <div className="lg:col-span-9 space-y-8">
          
          {/* Dashboard Hasil Utama */}
          <div className={`relative glass p-10 rounded-[3rem] border border-slate-800 transition-all duration-700 ${diagnosis.primaryDisorder.includes('Asidosis') ? 'border-rose-500/40 shadow-[0_0_30px_-10px_rgba(244,63,94,0.3)]' : diagnosis.primaryDisorder.includes('Alkalosis') ? 'border-blue-500/40 shadow-[0_0_30px_-10px_rgba(59,130,246,0.3)]' : 'border-emerald-500/40 shadow-[0_0_30px_-10px_rgba(16,185,129,0.3)]'}`}>
            <div className="absolute top-10 right-10 flex flex-col items-end gap-2">
               <Gauge className={`w-20 h-20 opacity-10 animate-spin-slow ${diagnosis.primaryDisorder.includes('Asidosis') ? 'text-rose-500' : 'text-cyan-500'}`} />
            </div>

            <div className="space-y-2 relative z-10">
              <span className="text-xs font-black uppercase tracking-[0.4em] text-slate-500">Hasil Interpretasi</span>
              <h2 className={`text-5xl md:text-7xl font-black transition-colors duration-500 tracking-tighter ${
                diagnosis.primaryDisorder.includes('Asidosis') ? 'text-rose-400' : 
                diagnosis.primaryDisorder.includes('Alkalosis') ? 'text-blue-400' : 'text-emerald-400'
              }`}>
                {diagnosis.primaryDisorder}
              </h2>
              
              <div className="flex flex-wrap gap-3 mt-6">
                <div className="bg-slate-800/80 px-4 py-2 rounded-2xl border border-slate-700 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_var(--neon-cyan)]"></span>
                  <span className="text-sm font-bold text-slate-300">{diagnosis.compensationStatus}</span>
                </div>
                {diagnosis.secondaryDisorders.map((dis, idx) => (
                   <div key={idx} className="bg-rose-500/10 px-4 py-2 rounded-2xl border border-rose-500/30 flex items-center gap-2 animate-pulse">
                    <AlertTriangle className="w-4 h-4 text-rose-500" />
                    <span className="text-sm font-bold text-rose-400">{dis}</span>
                   </div>
                ))}
              </div>
            </div>

            {/* Gauge Fisiologis */}
            <div className="mt-12 flex flex-col gap-4">
               <div className="flex justify-between text-[10px] font-black uppercase text-slate-600 tracking-widest px-1">
                 <span>Asidosis (6.8)</span>
                 <span className="text-emerald-500/50">Netral (7.4)</span>
                 <span>Alkalosis (7.8)</span>
               </div>
               <div className="h-4 w-full bg-slate-800/50 rounded-full overflow-hidden border border-slate-700 relative">
                  <div 
                    className={`h-full transition-all duration-1000 ease-out shadow-[0_0_20px] ${
                      inputs.pH < 7.35 ? 'bg-rose-500 shadow-rose-500/50' : 
                      inputs.pH > 7.45 ? 'bg-blue-500 shadow-blue-500/50' : 'bg-emerald-500 shadow-emerald-500/50'
                    }`}
                    style={{ width: `${phProgress}%` }}
                  ></div>
                  <div className="absolute top-0 bottom-0 w-0.5 bg-white/40 left-1/2 -translate-x-1/2"></div>
               </div>
            </div>
          </div>

          {/* Grid Analitik Mendalam */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* Analisis Anion Gap */}
            <div className="glass p-6 rounded-3xl border-slate-800 group overflow-hidden relative">
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                 <Stethoscope className="w-16 h-16" />
              </div>
              <h4 className="text-[10px] font-black text-cyan-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                <Droplets className="w-4 h-4" /> Audit Elektrolit
              </h4>
              <div className="space-y-4">
                <div className="flex justify-between items-end border-b border-slate-800 pb-3">
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Anion Gap (Terkoreksi Albumin)</p>
                    <p className={`text-2xl font-black mono ${diagnosis.anionGap.isHigh ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {diagnosis.anionGap.corrected.toFixed(1)}
                    </p>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-1 rounded uppercase ${diagnosis.anionGap.isHigh ? 'bg-rose-500/20 text-rose-500' : 'bg-emerald-500/20 text-emerald-500'}`}>
                    {diagnosis.anionGap.isHigh ? 'Tinggi' : 'Normal'}
                  </span>
                </div>
                {diagnosis.deltaGap && (
                  <div className="bg-slate-900/50 p-4 rounded-2xl border border-slate-800">
                    <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Rasio Delta (Δ/Δ)</p>
                    <p className="text-xl font-black mono text-cyan-400 mb-1">{diagnosis.deltaGap.ratio.toFixed(2)}</p>
                    <p className="text-[10px] text-slate-400 italic font-medium">{diagnosis.deltaGap.interpretation}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Ilmu Kompensasi */}
            <div className="glass p-6 rounded-3xl border-slate-800">
              <h4 className="text-[10px] font-black text-cyan-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                <Wind className="w-4 h-4" /> Dinamika Respiratorik
              </h4>
              <div className="space-y-4">
                {diagnosis.expectedPCO2 && (
                  <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800">
                    <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">pCO2 Prediksi (Winters)</p>
                    <div className="flex justify-between items-center">
                      <p className="text-xl font-black mono text-white">
                        {diagnosis.expectedPCO2.min.toFixed(1)} - {diagnosis.expectedPCO2.max.toFixed(1)}
                      </p>
                      <span className="text-[10px] font-bold text-slate-600">mmHg</span>
                    </div>
                  </div>
                )}
                {diagnosis.expectedHCO3 && (
                  <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800">
                    <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Target Bikarbonat Prediksi</p>
                    <div className="flex flex-col gap-2">
                      <div className="flex justify-between border-b border-slate-800/50 pb-1">
                        <span className="text-[10px] font-bold text-slate-600 uppercase">Akut</span>
                        <span className="text-sm font-black mono">{diagnosis.expectedHCO3.acute.toFixed(1)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[10px] font-bold text-slate-600 uppercase">Kronis</span>
                        <span className="text-sm font-black mono">{diagnosis.expectedHCO3.chronic.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>
                )}
                <div className="flex items-start gap-3 p-3 bg-cyan-500/5 border border-cyan-500/10 rounded-xl">
                   <Info className="w-4 h-4 text-cyan-500 shrink-0 mt-0.5" />
                   <p className="text-[9px] text-slate-400 leading-tight italic">
                     pCO2 di luar rentang prediksi mengindikasikan gangguan asam-basa campuran.
                   </p>
                </div>
              </div>
            </div>

            {/* Profil Oksigenasi */}
            <div className="glass p-6 rounded-3xl border-slate-800">
              <h4 className="text-[10px] font-black text-cyan-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                <Activity className="w-4 h-4" /> Kinerja Gas Exchange
              </h4>
              <div className="space-y-4">
                <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800">
                  <div className="flex justify-between mb-1">
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Gradien A-a</p>
                    <p className="text-[10px] font-bold text-slate-600">Batas: &lt;{diagnosis.oxygenation.aaExpected.toFixed(1)}</p>
                  </div>
                  <p className="text-xl font-black mono text-white">{diagnosis.oxygenation.aaGradient.toFixed(1)}</p>
                  <p className={`text-[9px] font-bold mt-1 ${diagnosis.oxygenation.aaGradient > diagnosis.oxygenation.aaExpected ? 'text-rose-500' : 'text-emerald-500'}`}>
                    {diagnosis.oxygenation.aaStatus}
                  </p>
                </div>
                <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800">
                   <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Rasio P/F (Horovitz)</p>
                   <div className="flex justify-between items-center">
                    <p className="text-xl font-black mono text-white">{diagnosis.oxygenation.pfRatio.toFixed(0)}</p>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-tighter ${
                      diagnosis.oxygenation.pfRatio < 300 ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {diagnosis.oxygenation.pfClass}
                    </span>
                   </div>
                </div>
              </div>
            </div>

          </div>

          {/* Bar Keselamatan */}
          <div className="p-5 bg-yellow-500/5 border border-yellow-500/10 rounded-3xl flex items-center gap-5">
             <div className="p-3 bg-yellow-500/10 rounded-2xl">
                <AlertTriangle className="w-6 h-6 text-yellow-500/60" />
             </div>
             <p className="text-[11px] text-yellow-500/60 leading-relaxed font-medium max-w-4xl italic">
               DISCLAIMER: Aplikasi ini dirancang untuk simulasi klinis. Interpretasi harus selalu dikorelasikan dengan kondisi hemodinamik pasien dan riwayat medis lengkap oleh tenaga medis berwenang.
             </p>
          </div>
        </div>
      </div>

      <footer className="mt-20 mb-10 pt-10 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-600">
        <p>© 2025 MedCore Dynamics • Bioscan Pro System</p>
        <div className="flex gap-8">
          <button className="hover:text-cyan-400 transition-colors">Panduan Rumus</button>
          <button className="hover:text-cyan-400 transition-colors">Referensi Jurnal</button>
          <button className="hover:text-cyan-400 transition-colors">Keamanan Data</button>
        </div>
      </footer>
    </div>
  );
};

export default App;
