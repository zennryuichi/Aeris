
export interface ABGInputs {
  pH: number;
  pCO2: number;
  HCO3: number;
  PaO2: number;
  FiO2: number;
  Na: number;
  Cl: number;
  K: number;
  Albumin: number;
  BUN: number;
  Glucose: number;
  Age: number;
}

export interface ABGInterpretation {
  physiologicalConsistency: boolean;
  hPlus: number;
  calculatedHPlus: number;
  primaryDisorder: string;
  secondaryDisorders: string[];
  compensationStatus: string;
  expectedPCO2?: { min: number; max: number };
  expectedHCO3?: { acute: number; chronic: number };
  anionGap: {
    observed: number;
    corrected: number;
    isHigh: boolean;
  };
  deltaGap?: {
    ratio: number;
    interpretation: string;
  };
  osmolarGap?: {
    calculated: number;
    gap: number;
  };
  oxygenation: {
    pfRatio: number;
    pfClass: string;
    aaGradient: number;
    aaExpected: number;
    aaStatus: string;
  };
}
