
import React from 'react';

interface InfoBadgeProps {
  label: string;
  value: string | number;
  color?: 'cyan' | 'red' | 'blue' | 'yellow' | 'green' | 'slate';
  description?: string;
}

const InfoBadge: React.FC<InfoBadgeProps> = ({ label, value, color = 'cyan', description }) => {
  const colors = {
    cyan: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    red: 'bg-red-500/10 text-red-400 border-red-500/30',
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    yellow: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    green: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    slate: 'bg-slate-500/10 text-slate-400 border-slate-500/30',
  };

  return (
    <div className={`p-4 rounded-xl border ${colors[color]} glass flex flex-col gap-1 transition-all hover:scale-[1.02]`}>
      <span className="text-xs uppercase tracking-wider font-semibold opacity-70">{label}</span>
      <span className="text-2xl font-bold mono">{value}</span>
      {description && <span className="text-xs opacity-80 mt-1 italic">{description}</span>}
    </div>
  );
};

export default InfoBadge;
